Submit-SigningRequest `
  -InputArtifactPath "publish/windows.exe" `
  -CIUserToken "AEVquz4p/MFkP7KiMAEJMipcmYZZzXuavTXDTbZW6wPd" `
  -OrganizationId "ec7e0b29-bda8-4762-8956-49e0648546a2" `
  -ProjectKey "Jaya" `
  -SigningPolicyKey "test-signing" `
  -OutputArtifactPath "publish_signed/windows.exe" `
  -WaitForCompletion

Move-Item -path "publish_signed/windows.exe" -destination "publish/windows.exe" -Force